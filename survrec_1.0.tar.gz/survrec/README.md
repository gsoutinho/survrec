# survrec: Estimation of the multivariate distributions for censored gap times


```survrec``` is an R package which provides estimates for the bivariate distribution
  function and bivariate survival function for censored gap times.

```
